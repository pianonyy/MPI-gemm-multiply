# Ручки
- `localhost:8888/estimate_route?path=0,1,3` - пример запроса 
- `localhost:8888/graph` - возвращает структуру графа