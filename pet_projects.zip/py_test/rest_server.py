import json

from flask import Flask, request, Response
from numpy.random import lognormal
from collections import defaultdict


class LogNormDistribution:
    def __init__(self, mu = 0.0, sigma = 1.0) -> None:
        self.mu = mu
        self.sigma = sigma

    def __str__(self):
        return f"mu = {self.mu}, sigma = {self.sigma}"

    def __repr__(self):
        return self.__str__()

    def generate_number(self) -> float:
        """
        return: random number from this distribution
        """
        return lognormal(self.mu, self.sigma, 1)[0]


class Graph:
    def __init__(self):
        self.vertices = defaultdict(dict)

    def load(self, filename: str):
        """
        filename:   file name with graph description
        return:     self
        """
        with open(filename, 'r') as json_file:
            edges = json.load(json_file)
        for edge in edges:
            vertex_from = edge.get('from')
            if vertex_from is None:
                print('vertex "from" not found')
                continue
            vertex_to = edge.get("to")
            if vertex_to is None:
                print('vertex "to" no found')
                continue
            mu = edge.get("mu", 0.0)
            sigma = edge.get("sigma", 1.0)
            self.vertices[vertex_from].update({vertex_to: LogNormDistribution(mu, sigma)})
        return self

    def get_structure(self):
        """
        return: graph description in the following format "vertex": ["ends of edges"]
        """
        structure = {}
        for vertex in self.vertices:
            outcoming = self.vertices.get(vertex, {}).keys()
            structure.update({f'{vertex}': list(outcoming)})
        return structure

    def traverse(self, path: list) -> list:
        """
        path:   list of vertices in visiting order
        return: delay time list
        """
        delay = []
        for vertex_from, vertex_to in zip(path[:-1], path[1:]):
            distribution = self.vertices.get(vertex_from, {}).get(vertex_to, LogNormDistribution())
            delay.append(distribution.generate_number())
        return delay


graph = Graph().load('graph.json') # here put the graph!
app = Flask('rest-api')


@app.route("/estimate_route")
def estimate_route():
    path = request.args.get('path', None)
    if path is None:
        return Response("empty path", status=403)
    vertices = list(map(int, path.split(',')))
    return Response(str(graph.traverse(vertices)), status=200)


@app.route("/graph")
def graph_structure():
    return Response(str(graph.get_structure()), status=200)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8888)
