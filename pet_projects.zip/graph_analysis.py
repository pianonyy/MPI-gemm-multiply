import numpy as np
from scipy.stats import lognorm
import sys
from tqdm import tqdm
import json
import requests


def all_paths_graph(graph) -> list:
    """
    graph: source graph
    return: list of all possible paths
    """
    if not graph:
        return []

    d = {}
    for i in range(len(graph)):
        d[i] = graph[i]  

    # apply DFS on DAG
    n = len(graph)
    stack = [(0, [0])]  # - store noth the (node, and the path leading to it)
    res = []
    while stack:
        node, path = stack.pop()
        # check leaf
        if node == n - 1:
            res.append(path)
        # traverse rest
        for nei in d[node]:
            stack.append((nei, path + [nei]))

    return res


def calculate_params(exp_run) -> tuple:
    """
    exp_run: 1 session
    return: tuple of means and std
    """
    total_sums = []
    for item in exp_run:
        total_sums.append(item.sum())

    return (np.array(total_sums).mean(), np.array(total_sums).std())

def get_name(path) -> list:
    """
    path: path to server to get graph description
    return: list representation of graph: 
    index means source node; list, corresponding to index, means linked nodes with index node
    """
    r = requests.get(
                f'http://127.0.0.1:8888/graph'
            )
    graph = r.text
    
    json_acceptable_string = graph.replace("'", "\"")
    d = json.loads(json_acceptable_string)
    d = dict(sorted(d.items()))
    nodes = list(d.values())
    nodes.append([])
    return nodes


if __name__ == "__main__":
    # get graph structure
    graph = get_name('http://127.0.0.1:8888/graph')
    
    # params
    trials = 1  # initial statitics
    alpha = 0.05
    times = 40

    orig_stdout = sys.stdout
    f = open(f'out_alpha_{alpha}_trials_{trials}.txt', 'w')
    sys.stdout = f

    print('our graph', graph)
    all_paths = all_paths_graph(graph)
    print("all possible paths", all_paths)

    # init distributions of all possible paths
    paths_distribution = [1 / len(all_paths) for i in range(0, len(all_paths))]
    print("init distribution", paths_distribution)

    for T in tqdm(range(times)):
        print(f"-------------------{T} sampling-------------------")
        
        statistics = []
        # run experiments
        for (num, path) in enumerate(all_paths):
            experiment = []
            print(path)
            for i in range(trials):
                r = requests.get(
                    f'http://127.0.0.1:8888/estimate_route?path={",".join(map(str, path))}'
                )
                experiment.append(np.array(r.json()))

                
            statistics.append(experiment)

        params = []

        # calculate params of statistics
        for path_stat in statistics:
            # print(calculate_params(path_stat))
            params.append(calculate_params(path_stat)[0])  # means

        inverse_params = []
        for i in range(len(params)):
            inverse_params.append(sum(params) - params[i])

        dist_weights = inverse_params / sum(inverse_params)

        # update distribution p_new = \alpha * p_old + (1 - \alpha) * p_desired
        paths_distribution = (
            alpha * np.array(paths_distribution) + (1.0 - alpha) * dist_weights
        )

        print("after update", paths_distribution)

        selected_path = np.random.choice(
            len(paths_distribution), 1, p=paths_distribution
        )
        print("selected_path: ", all_paths[selected_path[0]])

    sys.stdout = orig_stdout
    f.close()
